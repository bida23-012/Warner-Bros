# Netfilm-Clone
Netfilm Clone: Replicated the sleek movie streaming website using HTML and CSS.
